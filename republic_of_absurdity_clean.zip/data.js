window.RepublicData=(()=>{"use strict";
const countries=[
{id:"aurora",name:"آرورا",desc:"اقتصاد متعادل و دیپلماسی قوی.",effects:{economy:5,relations:4}},
{id:"veloria",name:"ولوریا",desc:"بازار پرپول و محبوبیت سیاسی.",effects:{money:120,popularity:3}},
{id:"nordica",name:"نوردیکا",desc:"شبکه انرژی پایدار و ثبات بالا.",effects:{energy:8,stability:3}},
{id:"solaria",name:"سولاریا",desc:"کشوری گرم با انرژی فراوان.",effects:{energy:10,economy:3}},
{id:"meridia",name:"مریدیا",desc:"اقتصاد تجاری و منابع نقدی.",effects:{money:80,economy:4}},
{id:"montara",name:"مونتارا",desc:"کوهستانی، منظم و باثبات.",effects:{stability:7,relations:3}},
{id:"pacifica",name:"پاسیفیکا",desc:"تجاری و محبوب در جهان.",effects:{money:100,relations:5}},
{id:"eastara",name:"ایستارا",desc:"رسانه‌های پرقدرت و جامعه فعال.",effects:{popularity:6,economy:2}},
{id:"novara",name:"نووارا",desc:"شبکه دیپلماتیک گسترده.",effects:{relations:8,popularity:2}},
{id:"federalis",name:"فدرالیس",desc:"صنعت قوی و دولت مرکزی.",effects:{economy:6,stability:2}}
];
const geos=[
{id:"capital",name:"پایتخت",effects:{stability:4,popularity:2}},
{id:"coast",name:"ساحلی",effects:{money:50,relations:3}},
{id:"mountain",name:"کوهستانی",effects:{stability:5,economy:-2}},
{id:"desert",name:"بیابانی",effects:{energy:-3,economy:2}},
{id:"forest",name:"جنگلی",effects:{stability:2,economy:3}},
{id:"industrial",name:"صنعتی",effects:{economy:7,energy:-4}},
{id:"agriculture",name:"کشاورزی",effects:{economy:3,popularity:3}},
{id:"border",name:"مرزی",effects:{relations:-2,stability:-2}}
];
const base=[
["بحران بودجه","وزارت دارایی می‌گوید منابع کافی برای همه وعده‌ها وجود ندارد.",["کاهش هزینه‌ها","مالیات موقت","استقراض ملی"],[{economy:-2,stability:1},{money:80,popularity:-3},{money:150,sanctions:1}]],
["اعتراض رسانه‌ای","یک موج خبری درباره عملکرد دولت شکل گرفته است.",["پاسخ شفاف","سکوت","تشکیل کمیته"],[{popularity:5,mediaNoise:-3},{popularity:-5,tension:2},{stability:2,bureaucracy:2}]],
["اختلال انرژی","شبکه برق با کمبود کوتاه‌مدت روبه‌رو شده است.",["سهمیه‌بندی","خرید فوری","سرمایه‌گذاری"],[{energy:5,popularity:-2},{money:-70,energy:10},{money:-50,energy:15,economy:3}]],
["پیشنهاد تجاری","یک شریک خارجی قرارداد اقتصادی جذابی پیشنهاد کرده است.",["قبول سریع","مذاکره سخت","رد قرارداد"],[{economy:5,relations:3},{money:70,economy:3},{reputation:2,relations:-3}]],
["شایعه عجیب","شایعه‌ای غیرعادی درباره دفتر ریاست جمهوری منتشر شده است.",["تکذیب رسمی","بررسی محرمانه","شوخی با شایعه"],[{mediaNoise:-2,reputation:2},{stability:2,mediaNoise:-4},{popularity:6,reputation:-1}]],
["فشار پارلمان","نمایندگان خواهان تغییر در یک برنامه مهم دولت هستند.",["سازش","مقابله","رأی‌گیری عمومی"],[{parliament:3,stability:2},{parliament:-4,popularity:3},{popularity:5,tension:2}]],
["بحران مرزی","گزارش‌هایی از افزایش تنش دیپلماتیک در منطقه می‌رسد.",["گفت‌وگو","افزایش آمادگی","میانجی‌گری"],[{relations:5,tension:-5},{stability:2,tension:4},{relations:8,reputation:2}]],
["کمبود کالا","قیمت چند کالای مهم افزایش پیدا کرده است.",["یارانه","آزادسازی بازار","کنترل موقت"],[{money:-80,popularity:5,inflation:-3},{economy:4,popularity:-4,inflation:2},{popularity:2,inflation:-2}]],
["اعتصاب اداری","بخشی از کارکنان دولت خواهان اصلاح شرایط کاری هستند.",["مذاکره","افزایش بودجه","جایگزینی مدیریت"],[{stability:3,bureaucracy:-2},{money:-60,popularity:3},{bureaucracy:-4,stability:-2}]],
["خبر موفقیت علمی","دانشمندان کشور به دستاورد مهمی رسیده‌اند.",["سرمایه‌گذاری بیشتر","اعلام عمومی","تجاری‌سازی"],[{money:-40,economy:7},{popularity:5,reputation:3},{money:80,economy:5}]]
];
const absurd=[
["وزارتخانه گم شد","یکی از ساختمان‌های اداری برای چند ساعت پیدا نمی‌شود.",["جست‌وجو","ساختمان جدید","وانمود کن اتفاقی نیفتاده"],[{bureaucracy:-3,stability:2},{money:-30,bureaucracy:2},{popularity:4,reputation:-2}]],
["جلسه با صندلی خالی","در نشست کابینه یک صندلی به شکل مشکوکی بیشترین توجه را جلب کرده است.",["جلسه را ادامه بده","صندلی را عوض کن","رأی‌گیری درباره صندلی"],[{stability:2},{mediaNoise:2,popularity:2},{reputation:5,parliament:1}]],
["پیش‌بینی هوا توسط اقتصاددان","یک مقام اقتصادی ادعا می‌کند می‌تواند آب‌وهوا را پیش‌بینی کند.",["دعوت به آزمایش","رد ادعا","پخش زنده"],[{reputation:3},{stability:1},{popularity:6,mediaNoise:3}]]
];
const specials={
10:["ده مرحله گذشت","دولت هنوز پابرجاست. یک بحران بزرگ در افق دیده می‌شود.",["بازسازی کابینه","تمرکز قدرت","جشن ملی"],[{stability:5,bureaucracy:-4},{parliament:-5,reputation:3},{popularity:8,money:-50}]],
20:["نقطه عطف","اقتصاد و افکار عمومی وارد مرحله تازه‌ای شده‌اند.",["اصلاح اقتصادی","کمک عمومی","ائتلاف سیاسی"],[{economy:8,popularity:-2},{money:-100,popularity:7},{relations:6,parliament:4}]],
30:["بحران جهانی","بازارهای جهان ناآرام شده‌اند و همه کشورها منتظر تصمیم شما هستند.",["همکاری جهانی","حفاظت از بازار","بی‌طرفی"],[{relations:10,tension:-8},{economy:6,inflation:3},{reputation:4,relations:2}]],
40:["چهار دهه بحران","رسانه‌ها عملکرد دولت را تاریخ‌ساز می‌دانند.",["شفافیت کامل","کمپین بزرگ","کناره‌گیری بخشی"],[{reputation:8,mediaNoise:-5},{popularity:10,money:-120},{stability:6,popularity:-3}]],
50:["روز میراث","آخرین تصمیم دوره ریاست جمهوری فرا رسیده است.",["میراث اقتصادی","میراث اجتماعی","میراث دیپلماتیک"],[{economy:10,money:100},{popularity:10,stability:4},{relations:12,reputation:10}]]
};
function make(x,i,rarity="NORMAL"){return{id:"e"+i,title:x[0],description:x[1],rarity,choices:x[2].map((t,n)=>({title:t,text:"این تصمیم مسیر مرحله بعد را تغییر می‌دهد.",effects:x[3][n]||{}}))}}
function all(){let a=base.map((x,i)=>make(x,i+1));let b=absurd.map((x,i)=>make(x,100+i,"ABSURD"));return a.concat(b)}
function special(stage){return specials[stage]?make(specials[stage],"S"+stage,"LEGENDARY"):null}
const endings=[
{id:"gold",title:"معمار آینده",minScore:180,text:"دولت شما با اقتصاد و اعتبار بالا به پایان رسید."},
{id:"people",title:"رئیس محبوب",minScore:120,text:"مردم شما را به خاطر حفظ محبوبیت به یاد خواهند آورد."},
{id:"diplomat",title:"معمار صلح",minScore:90,text:"شبکه روابط خارجی شما میراث اصلی دوره بود."},
{id:"survivor",title:"بازمانده بزرگ",minScore:0,text:"همه‌چیز عالی نبود، اما جمهوری را تا آخر نگه داشتید."}
];
return{countries,geographies:geos,allEvents:all,special,getEnding:s=>endings.find(e=>s>=e.minScore)||endings.at(-1),randomEvent(){let a=all();return a[Math.floor(Math.random()*a.length)]},news:["خبر فوری: بازارهای جهانی به تصمیم دولت واکنش نشان دادند.","تحلیل‌گران: رئیس جمهور با یک تصمیم غیرمنتظره روبه‌روست.","خبر فوری: جلسه کابینه تا اطلاع ثانوی ادامه دارد.","شبکه‌های خبری جهان، تصمیم جدید دولت را بررسی می‌کنند." ]};
})();