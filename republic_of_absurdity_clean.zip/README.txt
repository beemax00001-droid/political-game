REPUBLIC OF ABSURDITY — CLEAN REBUILD
Files:
index.html
style.css
data.js
ai.js
realtime.js
office3d.js
game.js

Put every file in the same folder. Open index.html in Acode Preview.
The game has a local fallback, so it can start even if Supabase or AI is unavailable.
Supabase uses the publishable key only; no secret token is included.
