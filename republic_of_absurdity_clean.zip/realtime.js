window.RepublicRealtime=(()=>{"use strict";
let room=null,client=null,channel=null,connected=false;
const URL="https://kkltydnftjwdgqtufdvl.supabase.co";
const KEY="sb_publishable_MB7iy1qpKxJf83gwh1TsjA_Bs0Ox6Bk";
async function load(){if(client)return client;try{if(!window.supabase){let s=document.createElement("script");s.src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2";document.head.appendChild(s);await new Promise((res,rej)=>{s.onload=res;s.onerror=rej})}client=window.supabase.createClient(URL,KEY);return client}catch(e){console.warn("Realtime unavailable",e);return null}}
async function connect(code,player,onMessage,onPresence){room=code;let c=await load();if(!c)return false;try{channel=c.channel("roa-"+code,{config:{broadcast:{self:true},presence:{key:player.id}}});channel.on("broadcast",{event:"game"},p=>onMessage&&onMessage(p.payload)).on("presence",{event:"sync"},()=>onPresence&&onPresence(channel.presenceState())).on("presence",{event:"join"},()=>onPresence&&onPresence(channel.presenceState())).on("presence",{event:"leave"},()=>onPresence&&onPresence(channel.presenceState()));await channel.subscribe(async status=>{connected=status==="SUBSCRIBED";if(connected)await channel.track(player)});return connected}catch(e){console.warn(e);return false}}
async function send(payload){if(channel&&connected)await channel.send({type:"broadcast",event:"game",payload})}
function leave(){try{channel&&channel.unsubscribe()}catch{}channel=null;connected=false}
return{connect,send,leave,get connected(){return connected}}})();