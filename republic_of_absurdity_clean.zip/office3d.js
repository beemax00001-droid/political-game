window.Office3D=(()=>{"use strict";
let el=null,raf=0;
function init(){el=document.getElementById("office");if(!el)return;let t=0;cancelAnimationFrame(raf);function loop(){t+=.006;el.style.transform=`perspective(900px) rotateX(${Math.sin(t)*.35}deg) translateZ(0)`;raf=requestAnimationFrame(loop)}loop()}
function event(){if(!el)return;el.classList.remove("flash");void el.offsetWidth;el.classList.add("flash")}
function news(text){let x=document.getElementById("monitorText");if(x)x.textContent=String(text).slice(0,28)}
return{init,event,news,resetCamera(){if(el)el.style.transform=""}}})();