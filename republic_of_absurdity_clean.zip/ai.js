window.RepublicAI=(()=>{"use strict";
const endpoint="https://political-game-ai.tm1190128.workers.dev/";
async function event(context){
try{
 const r=await fetch(endpoint,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({type:"event",context})});
 if(!r.ok)throw Error("AI "+r.status);
 const j=await r.json();const e=j.event||j.result||j;
 if(!e.title||!Array.isArray(e.choices)||e.choices.length!==3)throw Error("bad event");
 e.choices=e.choices.map((c,i)=>({title:c.title||["احتیاط","مذاکره","اقدام سریع"][i],text:c.text||"تصمیم خود را اجرا کنید.",effects:c.effects||{}}));
 return e;
}catch(err){console.warn("AI fallback:",err);return null}
}
return{event};
})();